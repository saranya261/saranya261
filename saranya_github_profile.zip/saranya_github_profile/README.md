<div align="center">

<img src="./assets/terminal.svg" alt="Saranya's developer terminal profile" width="100%"/>

<br/>

<a href="https://git.io/typing-svg">
  <img src="https://readme-typing-svg.demolab.com?font=JetBrains+Mono&weight=500&size=20&duration=2800&pause=800&color=42F5A1&center=true&vCenter=true&width=650&lines=Building+things+that+solve+problems;Learning+one+commit+at+a+time;DSA+%7C+Software+Development+%7C+Data+%7C+ML" alt="Typing SVG"/>
</a>

</div>

---

### `01 // about`

I'm Saranya, a Computer Science and Engineering student at **SRM University-AP**. I enjoy solving problems, learning how systems work, and building projects that connect software with real-world use cases.

- 🎓 B.Tech CSE · Expected 2028
- 📈 CGPA: 9.58 / 10
- 🧩 Currently strengthening DSA and software development fundamentals
- 🔎 Exploring data analytics and machine learning

### `02 // tech-stack`

<div align="center">

![C](https://img.shields.io/badge/C-111827?style=for-the-badge&logo=c&logoColor=A8B9CC)
![C++](https://img.shields.io/badge/C++-111827?style=for-the-badge&logo=cplusplus&logoColor=00599C)
![Python](https://img.shields.io/badge/Python-111827?style=for-the-badge&logo=python&logoColor=3776AB)
![Java](https://img.shields.io/badge/Java-111827?style=for-the-badge&logo=openjdk&logoColor=ED8B00)
![JavaScript](https://img.shields.io/badge/JavaScript-111827?style=for-the-badge&logo=javascript&logoColor=F7DF1E)
![HTML5](https://img.shields.io/badge/HTML5-111827?style=for-the-badge&logo=html5&logoColor=E34F26)
![CSS3](https://img.shields.io/badge/CSS3-111827?style=for-the-badge&logo=css3&logoColor=1572B6)
![React](https://img.shields.io/badge/React-111827?style=for-the-badge&logo=react&logoColor=61DAFB)
![Node.js](https://img.shields.io/badge/Node.js-111827?style=for-the-badge&logo=nodedotjs&logoColor=339933)
![Express](https://img.shields.io/badge/Express-111827?style=for-the-badge&logo=express&logoColor=white)
![MySQL](https://img.shields.io/badge/MySQL-111827?style=for-the-badge&logo=mysql&logoColor=4479A1)
![MongoDB](https://img.shields.io/badge/MongoDB-111827?style=for-the-badge&logo=mongodb&logoColor=47A248)
![Git](https://img.shields.io/badge/Git-111827?style=for-the-badge&logo=git&logoColor=F05032)
![GitHub](https://img.shields.io/badge/GitHub-111827?style=for-the-badge&logo=github&logoColor=white)
![VS Code](https://img.shields.io/badge/VS_Code-111827?style=for-the-badge&logo=visualstudiocode&logoColor=007ACC)

</div>

### `03 // selected-projects`

| Project | What it does | Stack |
|---|---|---|
| [AgriDetect](https://github.com/saranya261/agriDetect) | Rice leaf disease detection from images | Python · CNN · OpenCV |
| Alumni Mentorship Platform | Connects students and alumni through mentorship, matching and communication features | React · Node.js · Express · MongoDB |

### `04 // certifications`

- **MongoDB Certified Associate Developer** — MongoDB, April 2026
- **Pandas Certificate of Completion** — Kaggle, June 2026

### `05 // github-activity`

<div align="center">

<img height="165" src="https://github-readme-stats.vercel.app/api?username=saranya261&show_icons=true&hide_border=true&bg_color=0B1220&title_color=42F5A1&text_color=C8D6E5&icon_color=50C8FF&rank_icon=github" alt="GitHub statistics"/>
<img height="165" src="https://github-readme-stats.vercel.app/api/top-langs/?username=saranya261&layout=compact&hide_border=true&bg_color=0B1220&title_color=42F5A1&text_color=C8D6E5" alt="Most used languages"/>

</div>

<div align="center">
  <img src="https://streak-stats.demolab.com?user=saranya261&hide_border=true&background=0B1220&ring=42F5A1&fire=50C8FF&currStreakLabel=42F5A1&sideLabels=C8D6E5&currStreakNum=FFFFFF&sideNums=FFFFFF&dates=8FA8C1" alt="GitHub contribution streak"/>
</div>

### `06 // connect`

<div align="center">

[![GitHub](https://img.shields.io/badge/GitHub-saranya261-111827?style=for-the-badge&logo=github)](https://github.com/saranya261)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-Connect-111827?style=for-the-badge&logo=linkedin)](https://www.linkedin.com/in/saranya-chamala-3930a5324/)

<br/>

`$ echo "Thanks for stopping by."`

</div>
